require 'test_helper'

class TaskUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
