require 'test_helper'

class TaskCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
