class Status < ApplicationRecord
  belongs_to :task
end
